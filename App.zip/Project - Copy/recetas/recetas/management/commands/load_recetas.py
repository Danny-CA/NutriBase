import csv
from django.core.management.base import BaseCommand # type: ignore
from recetas.models import Receta

class Command(BaseCommand):
    help = 'Carga recetas desde un archivo CSV'

    def handle(self, *args, **kwargs):
        with open('recetas/data/recetas.csv', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                Receta.objects.create(
                    titulo=row['Title'],
                    porciones=int(row['Servings']),
                    tiempo=int(row['Ready in (minutes)']),
                    url_fuente=row['Source URL'],
                    imagen=row['Image'],
                    calorias=float(row['Calories']),
                    carbohidratos=float(row['Carbs (g)']),
                    grasa=float(row['Fat (g)']),
                    proteina=float(row['Protein (g)']),
                    ingredientes=row['Ingredients'],
                    instrucciones=row['Instructions'],
                )
        self.stdout.write(self.style.SUCCESS('Recetas cargadas exitosamente'))
