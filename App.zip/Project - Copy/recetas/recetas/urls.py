from django.urls import path # type: ignore
from .views import dashboard_view
from . import views

urlpatterns = [
    path('', views.inicio_view, name='inicio'),  # type: ignore
    path('dashboard-spoonacular/', dashboard_view, name='dashboard1'),
    path('dashboard-kaggle/', views.dashboard_diego_view, name='dashboard2'),
    path('about/', views.about, name='about'),

]
