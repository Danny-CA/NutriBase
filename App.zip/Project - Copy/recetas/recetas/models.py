from django.db import models # type: ignore

class Receta(models.Model):
    Title = models.CharField(max_length=255)
    Servings = models.IntegerField()
    Time = models.IntegerField()
    URL = models.URLField()
    Image = models.URLField()
    Calories = models.FloatField()
    Carbs = models.FloatField()
    Fat = models.FloatField()
    Protein = models.FloatField()
    Ingredients = models.TextField()
    Instructions = models.TextField()
    Category = models.CharField(max_length=20, blank=True, null=True) 

    def __str__(self):
        return self.titulo


class Diego(models.Model):
    name = models.CharField(max_length=255)
    minutes = models.IntegerField()
    n_steps = models.IntegerField()
    steps = models.TextField()
    description = models.TextField()
    ingredients = models.TextField()
    n_ingredients = models.IntegerField()
    calories = models.FloatField()
    total_fat_pdv = models.FloatField()
    sugar_pdv = models.FloatField()
    sodium_pdv = models.FloatField()
    protein_pdv = models.FloatField()
    saturated_fat_pdv = models.FloatField()
    carbohydrates_pdv = models.FloatField()
    ingredients_joined = models.TextField()
    tags_joined = models.TextField()
    category = models.CharField(max_length=50, blank=True, null=True) 


    def __str__(self):
        return self.name
