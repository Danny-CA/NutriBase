from django.shortcuts import render  # type: ignore
from .models import Receta
from .models import Diego
import numpy as np
from collections import Counter
import re
from collections import defaultdict



def inicio_view(request):
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')


def normalizar_ingrediente(ing):
    ing = ing.lower().strip()
    ing = re.sub(r'\b\d+/\d+\b', '', ing)  # Fracciones tipo 1/2
    ing = re.sub(r'\b\d+\b', '', ing)      # Números enteros
    ing = re.sub(r'\b(teaspoons?|tablespoons?|cups?|grams?|ounces?|oz|tsp|tbsp|ml|kg|g|l)\b', '', ing)
    ing = re.sub(r'\s+', ' ', ing)         # Espacios extra
    return ing.strip(' ,.')

def obtener_recetas_bajas_en_calorias(recetas, cantidad=5):
    recetas_ordenadas = recetas.order_by('Calories')[:cantidad]
    return [{"nombre": r.Title, "calorias": r.Calories} for r in recetas_ordenadas]

def dashboard_view(request):
    recetas = Receta.objects.all()
    total_recetas = recetas.count()

    # Medianas nutricionales
    median_calories = np.median([r.Calories for r in recetas])
    median_carbs = np.median([r.Carbs for r in recetas])
    median_fat = np.median([r.Fat for r in recetas])
    median_protein = np.median([r.Protein for r in recetas])

    # Recetas más calóricas
    max_calorias = recetas.order_by('-Calories').first().Calories if total_recetas else 1
    top_recetas_qs = recetas.order_by('-Calories')[:7]
    top_titulos = top_recetas_qs.values_list('Title', flat=True)
    top_recetas = [
        {
            'titulo': r.Title,
            'calorias': r.Calories,
            'porcentaje': round((r.Calories / max_calorias) * 100, 2)
        }
        for r in top_recetas_qs
    ]
    recetas_filtradas = recetas.exclude(Title__in=top_titulos)
    low_calories = obtener_recetas_bajas_en_calorias(recetas_filtradas, cantidad=5)


    # Ingredientes más usados
    ingredientes_list = []
    for r in recetas:
        ingredientes = r.Ingredients.split(',')
        ingredientes_list.extend([normalizar_ingrediente(i) for i in ingredientes if i.strip()])

    counter = Counter(ingredientes_list)
    top_ingredientes_dict = dict(counter.most_common(5))

    top_ingredientes = [
        {
            "ingrediente": k,
            "frecuencia": v,
            "porcentaje": round((v / total_recetas) * 100, 2)
        }
        for k, v in top_ingredientes_dict.items()
    ]

    # Conteo por categoría
    categoria_counter = defaultdict(int)
    for r in recetas:
        if r.Category:
            categoria_counter[r.Category.strip().capitalize()] += 1

    categorias = list(categoria_counter.keys())
    frecuencias = list(categoria_counter.values())

    contexto = {
        'median_calories': median_calories,
        'median_carbs': median_carbs,
        'median_fat': median_fat,
        'median_protein': median_protein,
        'top_recetas': top_recetas,
        'low_calories': low_calories,
        'top_ingredientes': top_ingredientes,
        'todas_recetas': recetas,
        'categorias': categorias,
        'frecuencias': frecuencias
    }

    return render(request, 'dashboard_spoonacular.html', contexto)
##############################################################################

def dashboard_diego_view(request):
    recetas = Diego.objects.all()
    
    # Categorías más comunes
    categorias = [r.category for r in recetas if r.category]
    counter_categorias = Counter(categorias)
    top_10 = counter_categorias.most_common(10)

    categorias_labels = [c[0] for c in top_10]
    categorias_frecuencias = [c[1] for c in top_10]

    # Medianas nutricionales
    median_calories = np.median([r.calories for r in recetas])
    median_carbs = np.median([r.carbohydrates_pdv for r in recetas])
    median_fat = np.median([r.total_fat_pdv for r in recetas])
    median_protein = np.median([r.protein_pdv for r in recetas])

    # Top 10 recetas más calóricas (calculando porcentaje respecto a la máxima)
    if recetas.exists():
        max_calories = recetas.order_by('-calories').first().calories
    else:
        max_calories = 1  # Para evitar división entre cero

    top_recetas = [
        {
            'nombre': r.name,
            'calorias': r.calories,
            'porcentaje': (r.calories / max_calories) * 100
        }
        for r in recetas.order_by('-calories')[:5]
    ]

    # 5 recetas con menos calorías
    low_calories = [
        {
            "nombre": r.name,
            "calorias": r.calories
        }
        for r in recetas.order_by('calories')[:5]
    ]


    # Ingredientes más usados
    ingredientes_list = []
    for r in recetas:
        # Separar usando múltiples posibles delimitadores (coma, punto y coma, guion, punto medio, etc.)
        ingredientes_crudos = re.split(r'[,;•\-]', r.ingredients_joined)
        
        # Limpiar y normalizar cada ingrediente
        ingredientes_list.extend([
            normalizar_ingrediente(i)
            for i in ingredientes_crudos if i.strip()
        ])

    counter = Counter(ingredientes_list)
    total_recetas = len(recetas)

    top_ingredientes_dict = dict(counter.most_common(5))
    top_ingredientes = [
        {
            "ingrediente": k.strip(),
            "frecuencia": v,
            "porcentaje": round((v / total_recetas) * 100, 2)
        }
        for k, v in top_ingredientes_dict.items()
    ]

    return render(request, 'dashboard_kaggle.html', {
        'median_calories': median_calories,
        'median_carbs': median_carbs,
        'median_fat': median_fat,
        'median_protein': median_protein,
        'top_recetas': top_recetas,
        'low_calories': low_calories,
        'top_ingredientes': top_ingredientes,
        'todas_recetas': recetas,
        'categorias': categorias_labels,
        'frecuencias': categorias_frecuencias,
    })



def normalizar_ingrediente(ing):
    ing = ing.lower().strip()
    ing = re.sub(r'\b\d+/\d+\b', '', ing)  # fracciones tipo 1/2
    ing = re.sub(r'\b\d+\b', '', ing)      # números enteros tipo 2, 1
    ing = re.sub(r'\b(teaspoons?|tablespoons?|cups?|grams?|ounces?|oz|tsp|tbsp|ml|kg|g|l)\b', '', ing)
    ing = re.sub(r'\s+', ' ', ing)         # eliminar espacios extra
    ing = ing.strip(' ,. ')
    return ing